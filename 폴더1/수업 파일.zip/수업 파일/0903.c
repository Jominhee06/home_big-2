#include <stdio.h>

int main() 
{

	for (int i = 0; i < 3; i++)
	{
		for (int k = 5; k > (2 * i) + 1 ; k--)
		{
			printf(" ");
		}
		for (int j = 0; j < 1 + (2 * i); j++)
		{

			printf("*");
		}
		
		printf("\n");
	}
	return 0;
}