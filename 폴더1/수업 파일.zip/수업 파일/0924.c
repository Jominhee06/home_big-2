#include <stdio.h>
#include <stdlib.h>
#include "myintQueue1.h"

int Initialize(ArrayIntQueue* q, int max) {
	q->num = 0;
	if ((q->que = calloc(max, sizeof(int))) == NULL) {
		q->max = 0;
		return -1;
	}
	q->max = max;
	return 0;
}

int Enque(ArrayIntQueue* q, int x) {
	if (q->num >= q->max) return -1;
	else {
		q ->[q->num++] = x; //num�� �� ������ ��ġ
		return 0;
	}
}

int Deque(ArrayIntQueue* q, int* x) {
	if (q->num <= 0) return -1;
	else {
		*x = q->que[0]; //�ֱ��� queue
		// �� ĭ�� ������ �̵�
		for (int i = 0; i < q->num - 1; i++)
			q->que[i] = q->que[i + 1];
		q->num--;
		return 0;
	}
}

int Peek(const ArrayIntQueue* q, int* x) {
	if (q->num <= 0) return -1;
	*x = q->que[0];
	return 0;
}

void clear(ArrayIntQueue* q) {
	q->num = 0;
}

int Capacity(const ArrayIntQueue* q) {
	return q->max;
}

int Size(const ArrayIntQueue* q) {
	return q->num;
}

int IsFull(const ArrayIntQueue* q, int* x) {
	return q->num >= q->max; // 1 or 0
}

int Search(const ArrayIntQueue* q, int* x) {
	for (int i = 0; i < q->num; i++) {
		if (q->que[i] == x)return i;
	}
	return -1; // �˻� ����
}

void Print(const ArrayIntQueue* q) {
	for (int i = 0; i < q->num; i++) printf("%d", q->que[i]);
	putchar('\n');
}

void Terminate(ArrayIntQueue* q) {
	if (q->que != NULL) free(q->que);

	q->max = q->num = 0;
}