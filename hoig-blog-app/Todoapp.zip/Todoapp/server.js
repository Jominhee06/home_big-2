const express = require('express');
const path = require('path'); // path 모듈 추가
const app = express();

app.use(express.static(__dirname + '/public'))

const {MongoClient} = require('mongodb');

let db
const url = 'mongodb+srv://jominhi0617:flyingkig569661@aiblog.p82yo.mongodb.net/?retryWrites=true&w=majority&appName=AIblog'

new MongoClient(url).connect().then((client)=>{
    console.log('DB연결성공')
    db = client.db('AIblog');
    // 서버 시작
    app.listen(8080, function(){
        console.log('http://localhost:8080에서 서버 실행중')
    });
}).catch((err)=>{
    console.log(err)
})

// 홈 페이지
app.get('/', function(요청, 응답){
    응답.sendFile(path.join(__dirname, 'index.html')); // path 모듈 사용
});

// menu1 페이지
app.get('/menu1', function(요청, 응답){
    응답.sendFile(path.join(__dirname, 'menu1.html')); // menu1.html 제공
});

// menu2 페이지
app.get('/menu2', function(요청, 응답){
    응답.sendFile(path.join(__dirname, 'menu2.html')); // menu2.html 제공
});

// menu3 페이지
app.get('/menu3', function(요청, 응답){
    응답.sendFile(path.join(__dirname, 'menu3.html')); // menu3.html 제공
});
