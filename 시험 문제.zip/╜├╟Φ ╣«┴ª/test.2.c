#include <stdio.h>

int main()
{
	int age = 30;
	int chest = 85;
	char size;

	if (age < 20) {
		if (chest < 85) {
			size = 'S';
		}
		else if (chest >= 85 && chest < 95) {
			size = 'M';
		}
		else if (chest >= 95)
			size = 'L';
		}
	else if (age >= 20 ){
		if (chest < 90) {
			size = 'S';
		}
		else if (chest >= 90 && chest < 100){
			size = 'M';
		}
		else if(chest >= 100)
		size = 'L';
	}
	printf("���̴� %d���̰� ������� %c�Դϴ�.\n", age, size);
	
	return 0;
}

